from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request,'event/index.html',{})

def about(request):
    return render(request,'event/about.html',{})

def event(request):
    return render(request,'event/event.html',{})

def make_event(request):
    return render(request,'event/form.html',{})

def log_in(request):
    return render(request,'event/signin.html',{})


def register(request):
    return render(request,'event/signup.html',{})


def contact(request):
    return render(request,'event/contact.html',{})

def portal(request):
    return render(request,'event/portal.html',{})